---
description: 31 commands
---

# 🔞 Anime

### Reactions

* **Description**: anime reactions
* **Command Usage**: `!anime <reaction>`&#x20;
* **Slash Usage**: `/anime`
* **Cooldown**: 5 seconds

| hug    | kiss | smug   |
| ------ | ---- | ------ |
| kiss   | poke | tickle |
| cuddle | slap | wink   |

### NSFW

* **Description**: show a random NSFW image from a selected category
* **Command Usage**: `!nsfw <category>`
* **Slash Usage**: `/nsfw`
* **Cooldown**: 5 seconds

| anal     | boobs    | bj      | blowjob      |
| -------- | -------- | ------- | ------------ |
| cumsluts | cumarts  | ero     | feet         |
| futanari | girlSolo | gasm    | hentai       |
| trap     | neko     | pussy   | pussyWankGif |
| spank    | yuri     | classic | femdom       |
| lesbian  | pussyArt |         |              |

{% hint style="warning" %}
**NSFW** commands can only be used in NSFW channels
{% endhint %}
