---
description: 7 commands
---

# 📨 Invites

| Command                             | Slash              | Description                                |
| ----------------------------------- | ------------------ | ------------------------------------------ |
| **!invitecodes**                    | **/invitecodes**   | list all your invites codes in this guild  |
| **!invites \[member]**              | **/inviter**       | shows inviter information                  |
| **!inviteranks**                    | **/inviteranks**   | view invite ranks configured in the server |
| **!invites \[member]**              | **/invites**       | view the number of invites of a member     |
| **!addinvites \<member> \<amount>** | **/addinvites**    | add invites to a member                    |
| **!resetinvites \<member>**         | **/resetinvites**  | clear previously added invites             |
| **!importinvites \[member]**        | **/importinvites** | add existing guild invites to users        |
